PIXIE³ — UPLOAD GUIDE (12 Jul 2026)
====================================
Drag ALL these files into github.com/yungketiak/Pixie/upload/main
(overwrite existing when asked), then commit:

  UPDATED:  index.html, works.html, process.html, contact.html, styles.css
  NEW:      faq.html, hotel-virtual-tour.html, event-venue-virtual-tour.html,
            retail-virtual-tour.html, office-virtual-tour.html
  NEW:      sitemap.xml, robots.txt

Do NOT upload this txt file. site.js is unchanged — no need to touch it.

Optional cleanup: delete v1.html from the repo (robots.txt now blocks it anyway).

WHAT CHANGED
- New palette live: #212431 base / #4F5D75 slate / #EA5C1F orange / #F5F5F5 text
- Buttons restyled: soft pills with orange glow
- JSON-LD structured data on every page (LocalBusiness/Service/FAQ/HowTo)
- Canonicals fixed www -> non-www
- FAQ page + 4 service landing pages, all cross-linked
- sitemap.xml + robots.txt (these were NOT live before — the previous zip never made it up)

AFTER UPLOAD (your side)
1. Google Search Console: verify pixiecube.space, submit sitemap.xml
2. Google Business Profile: create listing, use the same NAP (Plaza KLTS, 53000 KL)
3. Test share preview: paste pixiecube.space into WhatsApp
